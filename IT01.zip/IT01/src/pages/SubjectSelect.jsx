import React from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import './Home.css';

export default function SubjectSelect() {
  const navigate = useNavigate();

  const subjects = [
    { name: 'Web Development', slug: 'web', color: '#ab4e52', icon: '🌐' },
    { name: 'Networking',      slug: 'networking', color: '#ff7f50', icon: '📡' },
    { name: 'Cyber Security',  slug: 'security', color: '#6a5acd', icon: '🔒' },
    { name: 'Cloud Computing', slug: 'cloud', color: '#ffa500', icon: '☁️' }
  ];

  return (
    
    <div className="hero">
      
      

      <h1 className="title">Choose Your Subject</h1>
      

      <div className="features">
        {subjects.map(s => (
          <div
            key={s.slug}
            className="feature-card"
            style={{ cursor: 'pointer', borderTop: `4px solid ${s.color}` }}
            onClick={() => navigate(`/quiz/${s.slug}`)}
          >
            <h3 style={{ color: s.color }}>{s.icon} {s.name}</h3>
          </div>
        ))}
      </div>
    </div>
  );
}
