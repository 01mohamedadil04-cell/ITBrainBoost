import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import QuestionCard from '../components/QuestionCard';
import '../pages/Home.css';
<br><br></br></br>
export default function Quiz() {
  const { subject } = useParams();
  const navigate = useNavigate();

  const [questions, setQuestions] = useState([]);
  const [index, setIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  const QUESTIONS_PER_RUN = 20;

  useEffect(() => {
    async function loadQuestions() {
      try {
        const fileMap = {
          web: 'web_questions.json',
          networking: 'networking_questions.json',
          security: 'security_questions.json',
          cloud: 'cloud_questions.json'
        };
        const fileName = fileMap[subject];
        if (!fileName) throw new Error(`Unknown subject: ${subject}`);
        const mod = await import(`../data/${fileName}`);
        const pool = Array.isArray(mod.default) ? mod.default : mod;
        if (!Array.isArray(pool) || pool.length === 0) throw new Error('No questions found.');

        const shuffled = [...pool].sort(() => Math.random() - 0.5);
        const chosen = shuffled.slice(0, Math.min(QUESTIONS_PER_RUN, shuffled.length));

        setQuestions(chosen);
        setSelectedAnswers(Array(chosen.length).fill(null));
        setIndex(0);
        setScore(0);
        setFinished(false);

      } catch (err) {
        console.error('Error loading questions:', err);
        alert('Subject not found or error loading questions.');
        navigate('/', { replace: true });
      }
    }

    loadQuestions();
  }, [subject, navigate]);

  function handleAnswer(optionIndex) {
    if (finished) return;

    const copy = [...selectedAnswers];
    if (copy[index] !== null) return; 
    copy[index] = optionIndex;
    setSelectedAnswers(copy);

    if (questions[index].answer === optionIndex) setScore(s => s + 1);

    if (index + 1 < questions.length) {
      setIndex(i => i + 1);
    } else {
      setFinished(true);
    }
  }

  function goPrev() {
    setIndex(i => Math.max(0, i - 1));
  }

  function goNext() {
    setIndex(i => Math.min(questions.length - 1, i + 1));
  }

  function restart() {
    setSelectedAnswers(Array(questions.length).fill(null));
    setIndex(0);
    setScore(0);
    setFinished(false);
  }

  if (!questions.length) return <div className="container">Loading questions…</div>;

  if (finished) {
    return (
      <div className="container">
        <h1 className="title">{subject.toUpperCase()} Quiz Finished!</h1>
        <div className="info">Score: {score} / {questions.length}</div>

        <div style={{ marginTop: 16 }}>
          <button className="btn primary" onClick={restart}>Restart</button>
          <button className="btn secondary" onClick={() => navigate('/')}>Back Home</button>
        </div>

        <div style={{ marginTop: 16 }}>
          <h3>Review Answers:</h3>
          <ol>
            {questions.map((q, i) => (
              <li key={i} style={{ marginBottom: 12 }}>
                <strong>{q.question}</strong><br/>
                Your answer: {selectedAnswers[i] === null ? 'Not answered' : q.options[selectedAnswers[i]]}<br/>
                Correct: {q.options[q.answer]}
              </li>
            ))}
          </ol>
        </div>
      </div>
    );
  }

  const current = questions[index];

  return (
    <div className="container">
      <div className="header-fixed">
        <h1 className="title">{subject.toUpperCase()} Quiz</h1>
        <div className="info">Question {index + 1} of {questions.length}</div>
      </div>

      <QuestionCard
        question={current.question}
        options={current.options}
        onAnswer={handleAnswer}
        disabled={selectedAnswers[index] !== null}
      />

      <div className="controls" style={{ marginTop: 12, display: 'flex', gap: '10px', alignItems: 'center' }}>
        <button className="btn secondary" onClick={goPrev} disabled={index === 0}>Previous</button>
        <button className="btn secondary" onClick={goNext} disabled={index + 1 >= questions.length}>Next</button>
        <div style={{ marginLeft: 'auto', color: '#999' }}>Score: {score}</div>
      </div>
    </div>
  );
}
