// src/App.jsx (snippet)
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import SubjectSelect from './pages/SubjectSelect';
import Quiz from './pages/Quiz';
import Register from './pages/Register';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/subjects" element={<SubjectSelect />} />
        <Route path="/register" element={<Register />} />
        <Route path="/quiz/:subject" element={<Quiz />} />
      </Routes>
    </Router>
  );
}
