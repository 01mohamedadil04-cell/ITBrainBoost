import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Register from './pages/Register';
import SubjectSelect from './pages/SubjectSelect';
import Quiz from './pages/Quiz';
import Header from './components/Header';
import './pages/Home.css'; // Unified CSS for all pages

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/subjects" element={<SubjectSelect />} />
        <Route path="/quiz/:subject" element={<Quiz />} />
      </Routes>
    </Router>
  );
}

export default App;
