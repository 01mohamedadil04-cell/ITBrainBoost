import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import QuestionCard from '../components/QuestionCard';
import Confetti from 'react-confetti';

export default function Quiz() {
  const { subject } = useParams();
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [index, setIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  // load subject file dynamically
  useEffect(() => {
    async function load() {
      try {
        const mod = await import(`../data/${subject}_questions.json`);
        const pool = Array.isArray(mod.default) ? mod.default : mod;
        // shuffle
        const shuffled = pool.sort(() => Math.random() - 0.5);
        const take = Math.min(shuffled.length, 30); // up to 30
        const chosen = shuffled.slice(0, take);
        setQuestions(chosen);
        setSelectedAnswers(Array(take).fill(null));
      } catch (err) {
        alert('Subject not found or error loading questions.');
        navigate('/', { replace: true });
      }
    }
    load();
  }, [subject, navigate]);

  function handleAnswer(opt) {
    if (finished) return;
    const answers = [...selectedAnswers];
    if (answers[index] !== null) return; // answer once
    answers[index] = opt;
    setSelectedAnswers(answers);

    if (opt === questions[index].answer) {
      setScore(s => s + 1);
    }

    // move to next or finish
    if (index + 1 >= questions.length) {
      setFinished(true);
      const percent = ((opt === questions[index].answer ? score + 1 : score) / questions.length) * 100;
      if (percent >= 50) setShowConfetti(true);
    } else {
      setIndex(i => i + 1);
    }
  }

  function goPrev() {
    if (index === 0) return;
    setIndex(i => i - 1);
  }

  function goNext() {
    if (index + 1 >= questions.length) return;
    setIndex(i => i + 1);
  }

  function restart() {
    // reset everything
    setIndex(0);
    setSelectedAnswers(Array(questions.length).fill(null));
    setScore(0);
    setFinished(false);
    setShowConfetti(false);
  }

  if (!questions || questions.length === 0) return <div className="container">Loading questions…</div>;

  if (finished) {
    return (
      <div className="container">
        {showConfetti && <Confetti />}
        <div className="header">
          <div>
            <h1 className="title">Quiz Finished — {subject.toUpperCase()}</h1>
            <div className="info">Score: {score} / {questions.length}</div>
          </div>
        </div>

        <div style={{marginTop:16}}>
          <button className="btn" onClick={restart}>Restart</button>
          <button className="btn secondary" style={{marginLeft:10}} onClick={() => navigate('/')}>Back Home</button>
        </div>

        <div style={{marginTop:16}}>
          <h3>Summary</h3>
          <div style={{whiteSpace:'pre-wrap', color:'#dcdcdc', marginTop:8}}>
            {questions.map((q, i) => `${i+1}. ${q.question}\nYour: ${selectedAnswers[i] ?? '—'}\nAnswer: ${q.answer}\n`).join('\n')}
          </div>
        </div>
      </div>
    );
  }

  const current = questions[index];

  return (
    <div className="container">
      <div className="header">
        <div>
          <h1 className="title">{subject.toUpperCase()} Quiz</h1>
          <div className="info">Question {index + 1} of {questions.length}</div>
        </div>
      </div>

      <QuestionCard
        qIndex={index}
        total={questions.length}
        question={current.question}
        options={current.options}
        onAnswer={handleAnswer}
        disabled={false}
      />

      <div className="controls" style={{marginTop:12}}>
        <button className="btn secondary" onClick={goPrev} disabled={index === 0}>Previous</button>
        <button className="btn secondary" onClick={() => { setIndex(i => Math.min(i + 1, questions.length - 1)); }}>Skip</button>
        <button className="btn secondary" onClick={goNext} disabled={index + 1 >= questions.length}>Next</button>
        <div className="progress">Score: {score}</div>
      </div>

      <div className="footer">Your progress is saved for this session. Come back anytime to try another subject.</div>
    </div>
  );
}
