import React from 'react';

export default function QuestionCard({ qIndex, total, question, options, onAnswer, disabled }) {
  return (
    <div className="card">
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div>
          <div style={{fontSize:12, color:'#bdbdbd'}}>Question</div>
          <h3 className="question-title">{question}</h3>
        </div>
        <div style={{textAlign:'right'}}>
          <div style={{fontSize:12, color:'#bdbdbd'}}>Progress</div>
          <div style={{fontWeight:700}}>{qIndex + 1} / {total}</div>
        </div>
      </div>

      <div className="options" style={{marginTop:12}}>
        {options.map(opt => (
          <button
            key={opt}
            className="btn"
            onClick={() => onAnswer(opt)}
            disabled={disabled}
            style={{ textAlign:'left' }}
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}
