import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Header() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('quizUser') || 'null');

  const handleLogout = () => {
    localStorage.removeItem('quizUser');
    navigate('/', { replace: true });
  };

  return (
    <header style={headerStyle}>
      <h2 style={{ color: '#127521ff' }}>ITBrainBoostr</h2>
      {user && (
        <button onClick={handleLogout} style={logoutBtnStyle}>
          Logout
        </button>
      )}
    </header>
  );
}

const headerStyle = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '15px 30px',
  background: '#0f1117',
  boxShadow: '0 4px 10px rgba(0,0,0,0.3)',
  position: 'sticky',
  top: 0,
  zIndex: 100,
};

const logoutBtnStyle = {
  padding: '8px 18px',
  borderRadius: '8px',
  border: 'none',
  background: '#ab4e52',
  color: '#fff',
  cursor: 'pointer',
  fontWeight: 'bold',
  transition: 'all 0.3s ease',
};

